import { Model } from 'nestjs-dynamoose';
import { CreateUserInput } from './dto/create-user.input';
import { UpdateUserInput } from './dto/update-user.input';
import { UserInterface, UserKeyInterface } from './dto/users';
export declare class UsersService {
    private userModel;
    constructor(userModel: Model<UserInterface, UserKeyInterface>);
    create(createUserInput: CreateUserInput): Promise<import("nestjs-dynamoose").Document<UserInterface>>;
    findAll(): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<UserInterface>>>;
    findOneByEmail(email: string): Promise<import("nestjs-dynamoose").Document<UserInterface>>;
    findOne(id: string): Promise<import("nestjs-dynamoose").Document<UserInterface>>;
    update(id: string, updateUserInput: UpdateUserInput): Promise<import("nestjs-dynamoose").Document<UserInterface>>;
    remove(id: string): Promise<import("nestjs-dynamoose").Document<UserInterface>>;
}
