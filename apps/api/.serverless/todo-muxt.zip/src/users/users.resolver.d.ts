import { UsersService } from './users.service';
import { CreateUserInput } from './dto/create-user.input';
import { UpdateUserInput } from './dto/update-user.input';
export declare class UsersResolver {
    private readonly usersService;
    constructor(usersService: UsersService);
    createUser(createUserInput: CreateUserInput): Promise<import("nestjs-dynamoose").Document<import("./dto/users").UserInterface>>;
    findAll(): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<import("./dto/users").UserInterface>>>;
    findOne(id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/users").UserInterface>>;
    updateUser(updateUserInput: UpdateUserInput): Promise<import("nestjs-dynamoose").Document<import("./dto/users").UserInterface>>;
    removeUser(id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/users").UserInterface>>;
}
