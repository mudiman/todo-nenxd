export declare const UserSchema: import("dynamoose/dist/Schema").Schema;
declare const UserModel: import("dynamoose/dist/General").ModelType<import("dynamoose/dist/Item").AnyItem>;
export default UserModel;
export interface UserKeyInterface {
    id: string;
}
export interface UserInterface extends UserKeyInterface {
    email: string;
    first_name: string;
    last_name?: string;
    password: string;
}
