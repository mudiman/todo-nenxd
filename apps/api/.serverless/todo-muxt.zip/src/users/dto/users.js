"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSchema = void 0;
const dynamoose = require("dynamoose");
exports.UserSchema = new dynamoose.Schema({
    id: {
        type: String,
        hashKey: true,
    },
    first_name: {
        type: String,
        required: true,
    },
    last_name: {
        type: String,
        required: false,
    },
    password: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        index: {
            type: 'global',
            rangeKey: 'id',
            name: 'EmailIndex',
            project: true,
            throughput: 5,
        },
    },
}, {
    saveUnknown: true,
    timestamps: true,
});
const UserModel = dynamoose.model('User', exports.UserSchema);
exports.default = UserModel;
//# sourceMappingURL=users.js.map