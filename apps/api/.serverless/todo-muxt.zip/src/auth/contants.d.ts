export declare const jwtConstants: {
    secret: string;
};
