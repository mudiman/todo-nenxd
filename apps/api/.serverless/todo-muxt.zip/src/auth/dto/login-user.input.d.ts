export declare class LoginUserInput {
    email: string;
    password: string;
}
