export declare class LoggedUserOutput {
    access_token: string;
}
