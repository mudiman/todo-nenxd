import { AuthService } from './auth.service';
import { LoginUserInput } from './dto/login-user.input';
export declare class AuthResolver {
    private readonly authService;
    constructor(authService: AuthService);
    loginUser(loginUserInput: LoginUserInput): Promise<{
        access_token: string;
    }>;
}
