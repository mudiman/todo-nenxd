"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwtConstants = void 0;
exports.jwtConstants = {
    secret: 'ZL1PU!Ryt9*IqvK1mHwsCJZ9kCRsEv&7YWrsL4%TR#yX32U9jm',
};
//# sourceMappingURL=contants.js.map