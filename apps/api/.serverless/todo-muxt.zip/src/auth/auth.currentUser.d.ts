export declare const CurrentUser: (...dataOrPipes: unknown[]) => ParameterDecorator;
