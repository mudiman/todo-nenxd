import { Model } from 'nestjs-dynamoose';
import { CreateTodoInput } from './dto/create-todo.input';
import { UpdateTodoInput } from './dto/update-todo.input';
import { TodoInterface, TodoKeyInterface } from './dto/todos';
import { CurrentUserInterface } from 'src/auth/auth.currentUser';
export declare class TodosService {
    private todoModel;
    constructor(todoModel: Model<TodoInterface, TodoKeyInterface>);
    create(createTodoInput: CreateTodoInput, user: CurrentUserInterface): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    findAll(user: CurrentUserInterface): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<TodoInterface>>>;
    findOne(id: string, user: CurrentUserInterface): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    update(id: string, updateTodoInput: UpdateTodoInput, user: CurrentUserInterface): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    remove(id: string, user: CurrentUserInterface): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
}
