import { Model } from 'nestjs-dynamoose';
import { CreateTodoInput } from './dto/create-todo.input';
import { UpdateTodoInput } from './dto/update-todo.input';
import { User } from '../users/entities/user.entity';
import { TodoInterface, TodoKeyInterface } from './dto/todos';
export declare class TodosService {
    private todoModel;
    constructor(todoModel: Model<TodoInterface, TodoKeyInterface>);
    create(createTodoInput: CreateTodoInput, user: User): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    findAll(user: User): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<TodoInterface>>>;
    findOne(id: string, user: User): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    update(id: string, updateTodoInput: UpdateTodoInput, user: User): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
    remove(id: string, user: User): Promise<import("nestjs-dynamoose").Document<TodoInterface>>;
}
