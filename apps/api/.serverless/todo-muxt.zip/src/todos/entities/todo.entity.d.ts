import { User } from '../..//users/entities/user.entity';
import TodoModel from '../dto/todos';
export declare class Todo extends TodoModel {
    id: string;
    body: string;
    completed: number;
    user: User;
}
