export declare const TodoSchema: import("dynamoose/dist/Schema").Schema;
declare const TodoModel: import("dynamoose/dist/General").ModelType<import("dynamoose/dist/Item").AnyItem>;
export interface UserKey {
    id: string;
}
export interface User extends UserKey {
    email: string;
    first_name: string;
    last_name?: string;
}
export default TodoModel;
export interface TodoKeyInterface {
    id: string;
}
export interface TodoInterface extends TodoKeyInterface {
    id: string;
    body?: string;
    completed?: boolean;
    user?: Object;
}
