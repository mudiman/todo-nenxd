"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TodoSchema = void 0;
const dynamoose = require("dynamoose");
const users_1 = require("../../users/dto/users");
exports.TodoSchema = new dynamoose.Schema({
    id: {
        type: String,
        hashKey: true,
    },
    body: {
        type: String,
        required: true,
        index: {
            type: 'global',
            rangeKey: 'id',
            name: 'BodyIndex',
            project: true,
            throughput: 5,
        },
    },
    completed: {
        type: Boolean,
        default: false,
    },
    user: users_1.default,
}, {
    saveUnknown: true,
    timestamps: true,
});
const TodoModel = dynamoose.model('Todo', exports.TodoSchema);
exports.default = TodoModel;
//# sourceMappingURL=todos.js.map