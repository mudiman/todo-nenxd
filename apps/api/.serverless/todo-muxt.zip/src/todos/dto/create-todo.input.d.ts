export declare class CreateTodoInput {
    body: string;
    completed: boolean;
}
