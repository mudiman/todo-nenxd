import { TodosService } from './todos.service';
import { CreateTodoInput } from './dto/create-todo.input';
import { UpdateTodoInput } from './dto/update-todo.input';
import { CurrentUserInterface } from '../auth/auth.currentUser';
export declare class TodosResolver {
    private readonly todosService;
    constructor(todosService: TodosService);
    createTodo(user: CurrentUserInterface, createTodoInput: CreateTodoInput): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    findAll(user: CurrentUserInterface): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>>;
    findOne(user: CurrentUserInterface, id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    updateTodo(user: CurrentUserInterface, updateTodoInput: UpdateTodoInput): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    removeTodo(user: CurrentUserInterface, id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
}
