import { TodosService } from './todos.service';
import { CreateTodoInput } from './dto/create-todo.input';
import { UpdateTodoInput } from './dto/update-todo.input';
import { User } from '../users/entities/user.entity';
export declare class TodosResolver {
    private readonly todosService;
    constructor(todosService: TodosService);
    createTodo(user: User, createTodoInput: CreateTodoInput): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    findAll(user: User): Promise<import("nestjs-dynamoose").ScanResponse<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>>;
    findOne(user: User, id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    updateTodo(user: User, updateTodoInput: UpdateTodoInput): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
    removeTodo(user: User, id: string): Promise<import("nestjs-dynamoose").Document<import("./dto/todos").TodoInterface>>;
}
